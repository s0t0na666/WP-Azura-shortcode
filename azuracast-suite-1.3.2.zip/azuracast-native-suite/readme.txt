=== AzuraCast Suite ===
Contributors: openai
Tags: azuracast, radio, player, wordpress
Requires at least: 6.2
Requires PHP: 8.1
Stable tag: 1.3.2
License: GPL-2.0-or-later

Embed AzuraCast's own public player, history, podcasts and schedule pages, with additional WordPress shortcodes for now playing and Playing Next.

INSTALLATION
Upload the ZIP through Plugins > Add New > Upload Plugin, activate it, then open AzuraCast in wp-admin. Add one row per AzuraCast station. The station shortcode must be the exact AzuraCast shortcode (for example, dharmar_goa).

STATION SETTINGS
Configure the station shortcode, display name, AzuraCast server URL, AzuraCast public-page theme (Dark or Light), artwork option and optional CSS for WordPress-rendered now-playing components. There is no internal station alias. The station shortcode is used by WordPress shortcodes and API/WebSocket requests.

AZURACAST PUBLIC-PAGE EMBEDS
These shortcodes embed AzuraCast's own public pages in iframes. The URL patterns, query parameters and heights follow the embed snippets supplied by the site owner:

[azura_player station="dharmar_goa"]
URL: /public/dharmar_goa/embed?theme=dark
Height: 150px

[azura_history station="dharmar_goa"]
URL: /public/dharmar_goa/history?theme=dark
Height: 300px

[azura_podcasts station="dharmar_goa"]
URL: /public/dharmar_goa/podcasts?embed=true&theme=dark
Height: 400px

[azura_schedule station="dharmar_goa"]
URL: /public/dharmar_goa/schedule/embed?theme=dark
Height: 800px

The selected Dark/Light setting is passed to each public-page iframe as the theme query parameter. The plugin does not try to reproduce or style the content inside these iframes. The history iframe is AzuraCast's history page; its visible row count is controlled by AzuraCast, so the old WordPress shortcode limit attribute is not applied.

WORDPRESS-RENDERED SHORTCODES
[azura_nowplaying station="dharmar_goa"]
[azura_next_track station="dharmar_goa"]
The Playing Next shortcode displays only the queued track; it has no loading, connection or Now Playing status line.
Legacy Playing Next aliases: [azuracast_playing_next] and [azura_playing_next].

API AND LIVE UPDATES
Now Playing uses GET /api/nowplaying/{station_shortcode}. The WebSocket uses wss://{server}/api/live/nowplaying/websocket and subscribes to station:{station_shortcode}. API calls are made server-side through WordPress. The public-page iframe shortcodes do not depend on the plugin's API proxy.

AZURACAST REQUIREMENTS
The station's public pages must be enabled and accessible to visitors for the four iframe embeds. Enable Public APIs on the AzuraCast station for the now-playing and Playing Next components that consume public API data.

LOGGING
Logs are stored in uploads/azuracast-logs with index.php and .htaccess protection. The .htaccess rule depends on Apache/LiteSpeed; Nginx requires a server-level deny rule for this directory.

VALIDATION
PHP 8.1 syntax and live AzuraCast integration should be verified on the destination hosting environment before production use. This package has not been tested against the user's live AzuraCast instance or inside a live WordPress installation.
